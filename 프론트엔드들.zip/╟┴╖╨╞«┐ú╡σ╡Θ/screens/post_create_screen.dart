import 'package:flutter/material.dart';
import '_wip_stub.dart';

class PostCreateScreen extends StatelessWidget {
  const PostCreateScreen({super.key});
  @override
  Widget build(BuildContext context) => const WipScaffold(title: 'Post Create');
}

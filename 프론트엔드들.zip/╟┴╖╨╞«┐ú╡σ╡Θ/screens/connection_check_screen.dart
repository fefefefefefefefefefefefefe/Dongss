import 'package:flutter/material.dart';
import '_wip_stub.dart';

class ConnectionCheckScreen extends StatelessWidget {
  const ConnectionCheckScreen({super.key});
  @override
  Widget build(BuildContext context) => const WipScaffold(title: 'Connection Check');
}

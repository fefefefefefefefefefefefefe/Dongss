import 'package:flutter/material.dart';
import '_wip_stub.dart';

class EditProfileScreen extends StatelessWidget {
  const EditProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => const WipScaffold(title: 'Edit Profile');
}

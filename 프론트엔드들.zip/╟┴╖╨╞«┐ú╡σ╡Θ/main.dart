import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:dong_story/screens/write_community_post_screen.dart';
import 'package:dio/dio.dart';

/// ── core
import 'core/quick_ping.dart';
import 'core/deeplink.dart';
import 'core/notify_polling.dart';
import 'core/api_client.dart';

/// ── providers
import 'providers/net_provider.dart';
import 'providers/comment_provider.dart';
import 'providers/community_provider.dart';
import 'providers/auth_provider.dart';
import 'providers/post_provider.dart';
import 'providers/chat_provider.dart';
import 'providers/users_provider.dart';
import 'providers/notification_provider.dart';
import 'providers/search_provider.dart';
import 'providers/explore_provider.dart';

/// ── screens
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/community_detail_screen.dart';
import 'screens/post_detail_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/profile_edit_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/search_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/chat_list_screen.dart';
import 'screens/chat_room_screen.dart';
import 'screens/new_chat_screen.dart';
import 'screens/friends_management_screen.dart';
import 'screens/friend_recommend_screen.dart';
import 'screens/user_page_screen.dart';
import 'screens/notification_screen.dart';

/// 글쓰기 화면들
import 'screens/write_post_screen.dart';               // 홈 피드 글쓰기
void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // 비차단 서버 헬스 핑
  quickPingHealth();

  // 전역 오류 위젯
  ErrorWidget.builder = (details) => Material(
    color: Colors.white,
    child: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          '오류가 발생했어요:\n${details.exception}',
          textAlign: TextAlign.center,
        ),
      ),
    ),
  );

  runZonedGuarded(
        () => runApp(const MyApp()),
        (e, s) {
      // TODO: 필요시 로깅/크래시리포팅
      // debugPrint('UNCAUGHT: $e\n$s');
    },
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      colorSchemeSeed: Colors.green,
      useMaterial3: true,
    );

    return MultiProvider(
      providers: [
        /// ApiClient 싱글톤과 Dio 주입
        Provider<ApiClient>.value(value: ApiClient.I),
        Provider<Dio>(create: (c) => c.read<ApiClient>().dio),

        /// ChangeNotifiers
        ChangeNotifierProvider(create: (_) => NetProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => PostProvider()),
        ChangeNotifierProvider(create: (_) => CommentProvider()),
        ChangeNotifierProvider(create: (c) => ChatProvider(c.read<Dio>())), // ✅ Dio 주입
        ChangeNotifierProvider(create: (_) => UsersProvider()),
        ChangeNotifierProvider(create: (_) => NotificationProvider()),
        ChangeNotifierProvider(create: (_) => SearchProvider()),
        ChangeNotifierProvider(create: (_) => ExploreProvider()),
        ChangeNotifierProvider(create: (_) => CommunityProvider()),
      ],
      child: MaterialApp(
        title: 'DongStory',
        debugShowCheckedModeBanner: false,
        theme: theme,
        home: const _Bootstrapper(),

        /// ── 고정 routes
        routes: {
          '/home'             : (_) => const HomeScreen(),
          '/login'            : (_) => const LoginScreen(),
          '/community/detail' : (_) => const CommunityDetailScreen(embed: false),
          '/post'             : (_) => const PostDetailScreen(),
          '/chats'            : (_) => const ChatListScreen(),
          '/chat/new'         : (_) => const NewChatScreen(),

          /// 글쓰기
          '/write'            : (_) => const WritePostScreen(),            // 홈 피드 글쓰기
          '/write/community'  : (_) => const WriteCommunityPostScreen(),   // 커뮤니티 글쓰기
          '/write-community'  : (_) => const WriteCommunityPostScreen(),
          '/profile/edit'     : (_) => const ProfileEditScreen(),
          '/settings'         : (_) => const SettingsScreen(),
          '/search'           : (_) => const SearchScreen(embed: false),
          '/signup'           : (_) => const SignupScreen(),
          '/notifications'    : (_) => const NotificationScreen(),
          '/friends'          : (_) => const FriendsManagementScreen(),
          '/friends/recommend': (_) => const FriendRecommendScreen(),
          '/user'             : (_) => const UserPageScreen(),
        },

        /// ── 동적 라우트 (ID 포함 패턴 등)
        onGenerateRoute: (settings) {
          final raw = settings.name ?? '';
          final uri = Uri.tryParse(raw);
          final path = uri?.path ?? raw;

          // /post (arguments로 post 맵을 넘긴 경우)
          if (path == '/post') {
            final args = settings.arguments;
            return MaterialPageRoute(
              builder: (_) => PostDetailScreen(
                post: (args is Map) ? Map<String, dynamic>.from(args) : null,
              ),
              settings: settings,
            );
          }

          // 채팅방: /chat/room, /chat/room/123, /chat/room?id=123 등 유연 처리
          if (path == '/chat/room' || path.startsWith('/chat/room')) {
            int? roomId;
            final args = settings.arguments;

            // A) arguments 우선
            if (args is int) {
              roomId = args;
            } else if (args is Map) {
              final m = args;
              if (m['roomId'] is num) roomId = (m['roomId'] as num).toInt();
              else if (m['room_id'] is num) roomId = (m['room_id'] as num).toInt();
              else if (m['id'] is num) roomId = (m['id'] as num).toInt();
            } else {
              try { roomId = (args as dynamic).id as int?; } catch (_) {}
            }

            // B) /chat/room/123
            if (roomId == null) {
              final seg = uri?.pathSegments ?? [];
              if (seg.length >= 3 && seg[0] == 'chat' && seg[1] == 'room') {
                roomId = int.tryParse(seg[2]);
              }
            }

            // C) /chat/room?id=123 또는 roomId=123
            if (roomId == null) {
              final q = uri?.queryParameters ?? {};
              roomId = int.tryParse(q['roomId'] ?? q['id'] ?? '');
            }

            if (roomId == null) {
              return MaterialPageRoute(
                builder: (_) => const Scaffold(
                  body: Center(child: Text('채팅방 ID가 없습니다.')),
                ),
                settings: settings,
              );
            }

            return MaterialPageRoute(
              builder: (_) => ChatRoomScreen(roomId: roomId!),
              settings: settings,
            );
          }

          return null; // 나머지는 routes에서 처리
        },

        onUnknownRoute: (_) => MaterialPageRoute(
          builder: (_) => const Scaffold(
            body: Center(child: Text('존재하지 않는 페이지입니다.')),
          ),
        ),
      ),
    );
  }
}

/// 최초 1회만 바인더 초기화하고, 로그인 여부에 따라 분기
class _Bootstrapper extends StatefulWidget {
  const _Bootstrapper({super.key});
  @override
  State<_Bootstrapper> createState() => _BootstrapperState();
}

class _BootstrapperState extends State<_Bootstrapper> {
  static bool _inited = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_inited) return;
      _inited = true;
      DeepLinkBinder.ensureInitialized(context);
      NotifyPollingBinder.ensureInitialized(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final me = _pickMe(auth);
    return me == null ? const LoginScreen() : const HomeScreen();
  }

  /// AuthProvider의 현재 유저 필드명을 유연하게 핸들
  dynamic _pickMe(AuthProvider auth) {
    final a = auth as dynamic;
    try { final v = a.me; if (v != null) return v; } catch (_) {}
    try { final v = a.currentUser; if (v != null) return v; } catch (_) {}
    try { final v = a.user; if (v != null) return v; } catch (_) {}
    try { final v = a.loggedInUser; if (v != null) return v; } catch (_) {}
    return null;
  }
}

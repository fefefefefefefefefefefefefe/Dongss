// lib/screens/signup_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:dong_story/providers/auth_provider.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _form = GlobalKey<FormState>();

  final _username = TextEditingController();
  final _password = TextEditingController();
  final _password2 = TextEditingController();
  final _nickname = TextEditingController();
  final _name = TextEditingController(); // ✅ [최종] 이름 컨트롤러
  final _dateOfBirth = TextEditingController();

  // 💡 상태 변수
  String? _selectedGender;
  String? _selectedMajor;
  bool _busy = false;
  bool _agree = false;

  // 💡 성별 옵션
  final List<String> _genderOptions = ['남', '여'];

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    _password2.dispose();
    _nickname.dispose();
    _name.dispose(); // ✅ [최종] dispose 처리
    _dateOfBirth.dispose();
    super.dispose();
  }

  String? _req(String? v, {String label = '값'}) {
    if (v == null || v.trim().isEmpty) return '$label을(를) 입력하세요';
    return null;
  }

  // 💡 학과 목록 (유지)
  final List<String> _majorOptions = [
    '항공기계학과',
    '미래자동차학과',
    '전기공학과',
    '전자공학과',
    '디지털헬스케어과',
    'IT융합학과 ',
    '컴퓨터소프트웨어학과',
    '건축학과',
    '디지털방송콘텐츠학과',
    '게임콘텐츠과',
    '메타버스게임애니메이션과',
    '스마트드론과',
    '컴퓨터정보과',
    '자유전공학과',
    '호텔외식조리과 ',
    '보건의료행정과',
    '세무회계과',
    '마케팅과',
    '도시계획부동산학과',
    '호텔관광경영과',
    '아동보육과',
    '사회복지학과',
    '항공서비스학과',
    '글로벌중국비즈니스과',
    '사회복지상담과',
    '산업디자인학과',
    '시각디자인학과',
    '패션디자인과',
    '주얼리디자인과',
    '뷰티디자인과 ',
    '실내디자인학과',
    '콘텐츠크리에이터과',
    '웹툰과',
    '레저스포츠과',
    '경호스포츠과',
    '연기예술학과 ',
    '실용음악학과 ',
    'K-POP과',
    '엔터테인먼트경영과',
    '무대미술과',
    'AI응용소프트웨어과',
    'AI융합소프트웨어학과',
    '인공지능컴퓨팅과',
    '제과산업특화과',
  ];

  // 생년월일 유효성 검사 로직 (8자리 숫자 확인)
  String? _validateDateOfBirth(String? v) {
    if (v == null || v.trim().isEmpty) return '생년월일을 입력하세요';
    if (v.trim().length != 8 || int.tryParse(v.trim()) == null) {
      return '생년월일은 8자리 숫자(YYYYMMDD) 형식이어야 합니다.';
    }
    return null;
  }

  Future<void> _submit() async {
    if (_busy) return;
    if (!_agree) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('약관 동의가 필요합니다.')),
      );
      return;
    }

    // DropdownButtonFormField의 유효성 검사 추가 (성별 및 학과)
    if (_selectedGender == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('성별을 선택해주세요.')),
      );
      return;
    }
    if (_selectedMajor == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('학과를 선택해주세요.')),
      );
      return;
    }

    if (!_form.currentState!.validate()) return;
    if (_password.text != _password2.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('비밀번호가 일치하지 않습니다.')),
      );
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() => _busy = true);

    try {
      final auth = context.read<AuthProvider>();
      final a = auth as dynamic;

      final identifier = _username.text.trim();
      final email = '$identifier@du.ac.kr';

      // ✅ [최종] payload에 'name' 필드 추가 및 key 이름 정리
      final payload = {
        'username': identifier,
        'email': email,
        'password': _password.text,
        'student_no': identifier,
        'nickname': _nickname.text.trim(),
        'name': _name.text.trim(), // ✅ [최종] name 값 추가
        'department': _selectedMajor,
        'gender': _selectedGender,
        'birthday': _dateOfBirth.text.trim(),
      };

      // 1) auth.signup 호출 (가장 선호되는 방법)
      bool ok = await auth.signup(
        email: '$identifier@du.ac.kr',
        password: _password.text,
        nickname: _nickname.text.trim(),
        major: _selectedMajor ?? '',

        name: _name.text.trim(), // ✅ [최종] name 인자 전달

        studentId: identifier,
        gender: _selectedGender,
        dateOfBirth: _dateOfBirth.text.trim(),
      );

      // 3) register(username, email, password, ...) (대체 호출)
      if (!ok) {
        try {
          final r = await a.register?.call(
            username: payload['username'],
            email: payload['email'],
            password: payload['password'],
            student_no: payload['student_no'],
            nickname: payload['nickname'],
            name: payload['name'], // ✅ [최종] name 인자 사용
            department: payload['department'],
            gender: payload['gender'],
            birthday: payload['birthday'],
          );
          ok = (r == true) || (r?.success == true);
        } catch (_) {}
      }

      // 4) signUp(username:..., email:..., password:...) (대체 호출)
      if (!ok) {
        try {
          final r = await a.signUp?.call(
            username: payload['username'],
            email: payload['email'],
            password: payload['password'],
            studentId: payload['student_no'],
            nickname: payload['nickname'],
            name: payload['name'], // ✅ [최종] name 인자 사용
            department: payload['department'],
            gender: payload['gender'],
            dateOfBirth: payload['birthday'],
          );
          ok = (r == true) || (r?.success == true);
        } catch (_) {}
      }

      if (!mounted) return;
      if (ok) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('회원가입이 완료됐어요. 로그인해주세요.')),
        );
        Navigator.pushReplacementNamed(context, '/login');
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('회원가입에 실패했어요. 입력값을 확인해주세요.')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('회원가입 오류: $e')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final spacing = const SizedBox(height: 12);

    return Scaffold(
      appBar: AppBar(title: const Text('회원가입')),
      body: SafeArea(
        child: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // 학번 (아이디) 필드
              TextFormField(
                controller: _username,
                decoration: const InputDecoration(
                  labelText: '학번 (아이디)',
                  border: OutlineInputBorder(),
                ),
                validator: (v) => _req(v, label: '학번'),
                keyboardType: TextInputType.number,
                maxLength: 7,
                textInputAction: TextInputAction.next,
              ),
              spacing,

              // 이메일 필드 (자동 완성)
              ListenableBuilder(
                listenable: _username,
                builder: (context, child) {
                  final studentId = _username.text.trim();
                  final displayEmail = studentId.isEmpty
                      ? '학번을 입력하시면 자동으로 완성됩니다.'
                      : '$studentId@du.ac.kr';

                  return InputDecorator(
                    decoration: const InputDecoration(
                      labelText: '이메일 (자동 완성)',
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                    ),
                    child: Text(
                      displayEmail,
                      style: TextStyle(
                        fontSize: 16,
                        color: studentId.isEmpty ? Colors.grey : Colors.black,
                      ),
                    ),
                  );
                },
              ),
              spacing,

              // 비밀번호 필드
              TextFormField(
                controller: _password,
                decoration: const InputDecoration(
                  labelText: '비밀번호',
                  border: OutlineInputBorder(),
                ),
                obscureText: true,
                validator: (v) => _req(v, label: '비밀번호'),
                textInputAction: TextInputAction.next,
              ),
              spacing,

              // 비밀번호 확인 필드
              TextFormField(
                controller: _password2,
                decoration: const InputDecoration(
                  labelText: '비밀번호 확인',
                  border: OutlineInputBorder(),
                ),
                obscureText: true,
                validator: (v) => _req(v, label: '비밀번호 확인'),
                textInputAction: TextInputAction.next,
              ),
              spacing,

              // 닉네임 필드
              TextFormField(
                controller: _nickname,
                decoration: const InputDecoration(
                  labelText: '닉네임',
                  border: OutlineInputBorder(),
                ),
                validator: (v) => _req(v, label: '닉네임'),
                textInputAction: TextInputAction.next,
              ),
              spacing,

              // 이름 필드
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(
                  labelText: '이름',
                  border: OutlineInputBorder(),
                ),
                validator: (v) => _req(v, label: '이름'),
                textInputAction: TextInputAction.next,
              ),
              spacing,

              // 학과 선택 드롭다운
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: '학과',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.school_outlined),
                ),
                value: _selectedMajor,
                hint: const Text('학과를 선택하세요'),
                items: _majorOptions
                    .map((String value) => DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                ))
                    .toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedMajor = newValue;
                  });
                },
                validator: (v) => _req(v, label: '학과'),
              ),
              spacing,

              // 성별 선택 드롭다운
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: '성별',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.people_alt_outlined),
                ),
                value: _selectedGender,
                hint: const Text('성별을 선택하세요'),
                items: _genderOptions
                    .map((String value) => DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                ))
                    .toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedGender = newValue;
                  });
                },
                validator: (v) => _req(v, label: '성별'),
              ),
              spacing,

              // 생년월일 필드
              TextFormField(
                controller: _dateOfBirth,
                decoration: const InputDecoration(
                  labelText: '생년월일 (YYYYMMDD)',
                  border: OutlineInputBorder(),
                ),
                validator: _validateDateOfBirth,
                keyboardType: TextInputType.number,
                maxLength: 8,
                textInputAction: TextInputAction.done,
                onFieldSubmitted: (_) => _submit(),
              ),
              spacing,

              // 약관 동의 체크박스
              Row(
                children: [
                  Checkbox(
                    value: _agree,
                    onChanged: (v) => setState(() => _agree = v ?? false),
                  ),
                  const Expanded(
                    child: Text('이용약관 및 개인정보 처리방침에 동의합니다.'),
                  ),
                ],
              ),
              spacing,

              // 회원가입 버튼
              SizedBox(
                height: 48,
                child: FilledButton(
                  onPressed: _busy ? null : _submit,
                  child: _busy
                      ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                      : const Text('회원가입'),
                ),
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
                child: const Text('이미 계정이 있으신가요? 로그인'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
// lib/providers/auth_provider.dart

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../core/api_client.dart';
import '../core/auth_api.dart';

class AuthProvider extends ChangeNotifier {
  final _dio = ApiClient.I.dio;

  Map<String, dynamic>? _me;
  Map<String, dynamic>? get me => _me;
  bool get isLoggedIn => _me != null;

  String? _error;
  String? get error => _error;

  String _pickErr(Object e) {
    if (e is DioException) {
      final data = e.response?.data;

      if (kDebugMode) {
        print('==================================================');
        print('🚨 [회원가입 서버 오류 발생]');
        print('   HTTP 상태 코드: ${e.response?.statusCode}');
        print('   서버 응답 데이터: $data');
        print('==================================================');
      }

      if (data is Map && data['message'] is String) return data['message'] as String;
      if (data is String && data.isNotEmpty) return data;
      return e.message ?? '네트워크 오류가 발생했어요.';
    }
    return '알 수 없는 오류가 발생했어요.';
  }

  Future<bool> login({required String usernameOrEmail, required String password}) async {
    try {
      _error = null;
      final data = await AuthApi.I.login(
        usernameOrEmail: usernameOrEmail.trim(),
        password: password,
      );
      final user = (data['user'] ?? data['me']) as Map?;
      if (user != null) {
        _me = user.cast<String, dynamic>();
        notifyListeners();
        return true;
      }
      final meRes = await _dio.get('/me');
      _me = (meRes.data as Map).cast<String, dynamic>();
      notifyListeners();
      return true;
    } catch (e) {
      _error = _pickErr(e);
      notifyListeners();
      return false;
    }
  }

  Future<void> fetchMe() async {
    try {
      final res = await _dio.get('/me');
      _me = (res.data as Map).cast<String, dynamic>();
      _error = null;
      notifyListeners();
    } catch (e) {
      _error = _pickErr(e);
      notifyListeners();
    }
  }

  Future<void> logout() async {
    try {
      await AuthApi.I.logout();
    } finally {
      _me = null;
      notifyListeners();
    }
  }

  // ------------------------- 💡 회원가입 로직 (최종 수정: name 필드 추가 및 gender 소문자 수정) 💡 -------------------------
  Future<bool> signup({
    required String email,
    required String password,
    required String nickname,
    required String major,
    String? name, // ✅ [추가됨] 이름 필드
    String? studentId,
    String? gender,
    String? dateOfBirth,
  }) async {
    try {
      _error = null;

      // 1. 생년월일 형식 변환: YYYYMMDD -> YYYY-MM-DD
      String? formattedDate;
      if (dateOfBirth != null && dateOfBirth.length == 8) {
        formattedDate = '${dateOfBirth.substring(0, 4)}-'
            '${dateOfBirth.substring(4, 6)}-'
            '${dateOfBirth.substring(6, 8)}';
      }

      // 2. 성별 코드 변환: '남'/'여' -> 'male'/'female' (소문자 Enum 가정)
      String? genderCode;
      if (gender == '남') {
        genderCode = 'male';
      } else if (gender == '여') {
        genderCode = 'female';
      }

      final body = <String, dynamic>{
        'email': email.trim(),
        'password': password,
        'nickname': nickname.trim(),
        'department': major,

        // ✅ [추가됨] 이름 필드 (name)
        if (name != null && name.isNotEmpty) 'name': name.trim(),

        // 서버 필수 필드: studentId 값을 username, student_no 모두에 할당
        if (studentId != null && studentId.isNotEmpty) 'username': studentId,
        if (studentId != null && studentId.isNotEmpty) 'student_no': studentId,

        // 성별: 소문자 코드 사용
        if (genderCode != null) 'gender': genderCode,

        // 생년월일: 변환된 날짜 문자열 사용
        if (formattedDate != null) 'birthday': formattedDate,
      };

      // 경로: '/auth/register' 사용
      await _dio.post('/auth/register', data: body);

      return true;
    } catch (e) {
      _error = _pickErr(e);
      notifyListeners();
      return false;
    }
  }
  // ----------------------------------------------------------------------


  // ... (나머지 헬퍼 메서드들은 그대로 유지)
  Map<String, dynamic> _asMap(dynamic v) =>
      (v is Map) ? v.cast<String, dynamic>() : <String, dynamic>{};

  Map<String, dynamic> _mutableUserMap() {
    _me ??= <String, dynamic>{};
    if (_me!['data'] is Map && (_me!['data'] as Map)['user'] is Map) {
      return (_me!['data'] as Map)['user'].cast<String, dynamic>();
    }
    for (final k in ['user', 'me', 'profile']) {
      if (_me![k] is Map) return (_me![k] as Map).cast<String, dynamic>();
    }
    return _me!;
  }

  void _mirrorStrings(Map<String, dynamic> into, Map<String, String> kvs) {
    for (final e in kvs.entries) {
      into[e.key] = e.value;
    }
  }

  Future<void> updateProfile({
    String? nickname,
    String? intro,
    String? avatarUrl,
  }) async {
    final body = <String, dynamic>{
      if (nickname != null) 'nickname': nickname,
      if (intro != null) 'intro': intro,
      if (avatarUrl != null) ...{
        'profile_img': avatarUrl,
        'avatarUrl': avatarUrl,
        'profile_image': avatarUrl,
        'avatar_url': avatarUrl,
      },
    };

    try {
      Response res;
      try {
        res = await _dio.patch('/me', data: body);
      } on DioException catch (e) {
        if (e.response?.statusCode == 404) {
          res = await _dio.patch('/users/me', data: body);
        } else {
          rethrow;
        }
      }

      Map<String, dynamic>? updated;
      final data = res.data;
      if (data is Map) {
        if (data['user'] is Map) {
          updated = (data['user'] as Map).cast<String, dynamic>();
        } else if (data['me'] is Map) {
          updated = (data['me'] as Map).cast<String, dynamic>();
        } else if (data['data'] is Map) {
          final d = (data['data'] as Map);
          if (d['user'] is Map) {
            updated = (d['user'] as Map).cast<String, dynamic>();
          } else {
            updated = d.cast<String, dynamic>();
          }
        } else {
          updated = data.cast<String, dynamic>();
        }
      }

      _me ??= <String, dynamic>{};
      final target = _mutableUserMap();

      if (updated != null && updated.isNotEmpty) {
        target.addAll(updated);
        _me!.addAll(updated);
      } else {
        if (nickname != null) {
          for (final m in [_me!, target]) {
            _mirrorStrings(m, {
              'nickname': nickname,
              'displayName': nickname,
              'display_name': nickname,
              'name': (m['name'] ?? nickname).toString(),
            });
          }
        }
        if (intro != null) {
          for (final m in [_me!, target]) {
            _mirrorStrings(m, {
              'intro': intro,
              'bio': intro,
              'about': intro,
              'description': intro,
            });
          }
        }
        if (avatarUrl != null) {
          for (final m in [_me!, target]) {
            _mirrorStrings(m, {
              'avatar': avatarUrl,
              'avatar_url': avatarUrl,
              'profile_image': avatarUrl,
              'profile_image_url': avatarUrl,
              'avatarUrl': avatarUrl,
            });
            final cur = (m['_avatar_v'] is int) ? m['_avatar_v'] as int : 0;
            m['_avatar_v'] = cur + 1;
          }
          final cur = (_me!['_avatar_v'] is int) ? _me!['_avatar_v'] as int : 0;
          _me!['_avatar_v'] = cur + 1;
        }
      }

      _error = null;
      notifyListeners();
    } catch (e) {
      _error = _pickErr(e);
      notifyListeners();
      rethrow;
    }
  }
}
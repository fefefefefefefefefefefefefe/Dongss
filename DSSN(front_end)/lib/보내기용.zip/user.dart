// lib/models/user.dart

class User {
  final String id; // ✅ 학번(최대 7자리)으로 사용, String 타입 고정
  final String email; // 필수 필드
  String nickname; // 💡 프로필 편집을 위해 final 제거
  // final String major; // ❌ 학번을 ID로 사용함에 따라 제거됨
  final List<String> friends;
  final List<String> likedPosts;
  String? profileImageUrl;
  String? bio;

  User({
    required this.id,
    required this.email,
    required this.nickname,
    // required this.major, // ❌ 제거됨
    required this.friends,
    required this.likedPosts,
    this.profileImageUrl,
    this.bio,
  });

  // fromJson 팩토리 생성자
  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      // id는 String으로 파싱 (학번)
      id: (json['id'] ?? '').toString(),
      email: (json['email'] ?? '').toString(),

      // nickname 파싱
      nickname: (json['nickname'] ?? json['nick'] ?? json['username'] ?? '').toString(),

      // major 필드 파싱 로직 ❌ 제거됨
      // major: (json['major'] ?? '').toString(),

      bio: json['bio']?.toString(),

      // profileImageUrl 파싱
      profileImageUrl: (json['profile_img'] ?? json['profileImg'] ?? json['avatar'] ?? json['profileImageUrl'])?.toString(),

      // List<String> 파싱
      friends: _parseStringList(json['friends']),
      likedPosts: _parseStringList(json['likedPosts']),
    );
  }

  // List<dynamic>을 List<String>으로 안전하게 파싱하는 헬퍼 함수
  static List<String> _parseStringList(dynamic raw) {
    if (raw is List) {
      return raw.map((e) => e.toString()).where((e) => e.isNotEmpty).toList();
    }
    return const [];
  }

  // copyWith 메서드: 객체의 불변성을 유지하며 특정 필드만 변경된 새 객체를 생성
  User copyWith({
    String? id,
    String? email,
    String? nickname,
    // String? major, // ❌ 제거됨
    String? bio,
    String? profileImageUrl,
    List<String>? friends,
    List<String>? likedPosts,
  }) {
    return User(
      id: id ?? this.id,
      email: email ?? this.email,
      nickname: nickname ?? this.nickname,
      // major: major ?? this.major, // ❌ 제거됨
      bio: bio ?? this.bio,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      friends: friends ?? this.friends,
      likedPosts: likedPosts ?? this.likedPosts,
    );
  }

  // 닉네임이 주 표시 이름이 됩니다.
  String get displayName => nickname.trim().isNotEmpty ? nickname.trim() : '이름 없음';
}